﻿# Pimp your treasure chests!

### What does this do?
<b> This mod was engineered to add some in game icons to Epic Loot's treasure chests so I can find them a little bit easier when I am out on a tresure Hunt</b>

## V0.0.1 Release
* First release of the mod

### In GameShots

<img src="https://github.com/sbtoonz/CoolerEpicLootChests/raw/master/CoolerEpicLootChests/Thunderstore/Capture.2PNG.PNG"></img>
<img src="https://github.com/sbtoonz/CoolerEpicLootChests/raw/master/CoolerEpicLootChests/Thunderstore/screen1.PNG"></img>
<img src="https://github.com/sbtoonz/CoolerEpicLootChests/raw/master/CoolerEpicLootChests/Thunderstore/Capture.PNG"></img>
